//package com.example.demo.Task02;
//
//import jakarta.persistence.*;
//
//@Entity
//public class Product {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    @Column(nullable = false)
//    private String name;
//
//    @ManyToOne
//    @JoinColumn(name = "category_id")
//    private Category category;
//
//	public Object getName() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public Object getCategory() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public void setName(Object name2) {
//		// TODO Auto-generated method stub
//		
//	}
//
//	public void setCategory(Object category2) {
//		// TODO Auto-generated method stub
//		
//	}
//
//  
//}

package com.example.demo.Task02;

import jakarta.persistence.*;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

   
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}

