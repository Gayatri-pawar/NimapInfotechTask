package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.Task02.Category;
import com.example.demo.Task02.Product;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ProductService;

@SpringBootApplication
public class Task02Application {

	public static void main(String[] args) {
//		SpringApplication.run(Task02Application.class, args);
		ConfigurableApplicationContext context = SpringApplication.run(Task02Application.class, args);

		  CategoryService categoryService = context.getBean(CategoryService.class);
          ProductService productService = context.getBean(ProductService.class);
	      
	        Category category = new Category();
	        category.setName("Electronics");
	        categoryService.createCategory(category);
	        category.setName("Electronics");
	        categoryService.createCategory(category);
	        category.setName("Mobile");
	        categoryService.createCategory(category);
	        category.setName("Pipes");
	        categoryService.createCategory(category);
	        category.setName("Tablet");
	        categoryService.createCategory(category);
	        category.setName("Computer");
	        categoryService.createCategory(category);
	        Category category2 = new Category();
	        category2.setName("Mobile");
	        categoryService.createCategory(category2);

	        Category category3 = new Category();
	        category3.setName("Pipes");
	        categoryService.createCategory(category3);

	        Category category4 = new Category();
	        category4.setName("Tablet");
	        categoryService.createCategory(category4);

	        Category category5 = new Category();
	        category5.setName("Computer");
	        categoryService.createCategory(category5);
	        
//	        Product product1 = new Product();
//	        product1.setName("Laptop");
//	        product1.setCategory(category);  
//	        productService.createProduct(product1);
//	        Product product2 = new Product();
//	        product2.setName("Laptop");
//	        product2.setCategory(category2);  
//	        productService.createProduct(product2);
	        Product product2 = new Product();
	        product2.setName("Smartphone");
	        product2.setCategory(category2);  
	        productService.createProduct(product2);

	        Product product3 = new Product();
	        product3.setName("Pipe");
	        product3.setCategory(category3);  
	        productService.createProduct(product3);

	        Product product4 = new Product();
	        product4.setName("Tablet");
	        product4.setCategory(category4); 
	        productService.createProduct(product4);

	        Product product5 = new Product();
	        product5.setName("Desktop Computer");
	        product5.setCategory(category5);  
	        productService.createProduct(product5);
	}

}
