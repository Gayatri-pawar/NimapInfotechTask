//package com.example.demo.Task02;
//
//import org.springframework.data.annotation.Id;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//
//@Entity
//public class Category {
//
//	 @Id
//	 @GeneratedValue(strategy = GenerationType.IDENTITY)
//	 
//	 private int id;
//	 private String name;
//	 public int getId() {
//	        return id;
//	    }
//
//	    public void setId(int id) {
//	        this.id = id;
//	    }
//	    
//	public Object getName() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public void setName(Object name) {
//		// TODO Auto-generated method stub
//		
//	}
//
//}

package com.example.demo.Task02;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Category {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;

    // Getter for ID
    public int getId() {
        return id;
    }

    // Setter for ID
    public void setId(int id) {
        this.id = id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }
}

